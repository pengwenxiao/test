require "import"
import "android.widget.*"
import "android.view.*"
import "android.widget.Toast"
dip2px=function(dpValue)
  return dpValue * this.getResources().getDisplayMetrics().density + 0.5
end

import "android.graphics.Paint"
import "android.graphics.Color"
import "android.content.Context"
import "android.graphics.Rect"


BarColor={0xFF397DFF,0xFFFF9700,0xFF6AB284,0xFFFEC107}
--适用于所有56dp控件，非56dp会显示异常
Progress=0--动画进度0.0--0.1
isAnimType=1--动画类型
ColorN2=0xffffffff--线条颜色
ActionBarColor=BarColor[math. random(1,#BarColor)]

IsDO=true--true反转false正转
San_1=LuaDrawable(function(c,p,d)
  --Thr_true_seek.setProgress(Progress*100)--设置拖动条进度。。
  cWidth=c.Width
  cHeight=c.Height
  SizeH=dip2px(15)
  SizeW=dip2px(15)
  p.setDither(true)
  --p.setStrokeCap(Paint.Cap.ROUND)
  p.setAntiAlias(true); --抗锯齿
  p.setStyle(Paint.Style.FILL);--实线
  c.drawColor(ActionBarColor);
  p.setColor(ColorN2)
  if isAnimType==1 then
    SizeH=dip2px(15)
    SizeW=dip2px(17)
    p.setStrokeCap(Paint.Cap.ROUND)
    p.setStrokeWidth(dip2px(2));
    c.save();
    c.translate(dip2px(20),((cHeight/2)-(SizeH/3)))
    c.rotate((IsDO and (180+((1-Progress)*180)) or ((Progress)*180)),(SizeW/2),SizeH/3)

    pts1={0,0,SizeW-(Progress*(SizeW/2.4)),0}
    c.save();
    c.translate(0,Progress*dip2px(8.4));
    c.rotate(Progress*45,SizeW,SizeH/3)
    c.drawLines(pts1,p);
    c.restore();

    pts2={0,(SizeH/3)*2,SizeW-(Progress*(SizeW/2.4)),(SizeH/3)*2}
    c.save();
    c.translate(0,Progress*-dip2px(8.4));
    c.rotate(Progress*-45,SizeW,(SizeH/3))
    c.drawLines(pts2,p);
    c.restore();

    pts3={Progress*dip2px(1),SizeH/3,SizeW-(Progress*(SizeW/4)),SizeH/3}
    c.drawLines(pts3,p);

   elseif isAnimType==2 then
    SizeH=dip2px(15)
    SizeW=dip2px(18)
    p.setStrokeCap(Paint.Cap.BUTT)
    p.setStrokeWidth(dip2px(1.7));
    c.translate(dip2px(19),((cHeight/2)-(SizeH/3)))
    c.save();
    p.setStrokeWidth(dip2px(1.7)+(Progress*2));
    c.scale(1-(Progress*0.2),1-(Progress*0.2), (SizeW/2),SizeH/3);
    c.rotate((IsDO and (180+((1-Progress)*180)) or (Progress*180)),(SizeW/2),SizeH/3)
    c.translate(-Progress*(SizeW/2.2),0)
    pts1={0,0,SizeW+(Progress*((SizeW/3)-dip2px(0.8))),0}
    c.save();
    c.translate(0,Progress*((SizeH+dip2px(0.3))/2));
    c.rotate(Progress*45,SizeW,SizeH/3)
    c.drawLines(pts1,p);
    c.restore();

    pts2={0,(SizeH/3)*2,SizeW+(Progress*((SizeW/3)-dip2px(0.8))),(SizeH/3)*2}
    c.save();
    c.translate(0,-Progress*((SizeH+dip2px(0.4))/2));
    c.rotate(Progress*-45,SizeW,(SizeH/3))
    c.drawLines(pts2,p);
    c.restore();

    if Progress<1 then
      pts3={(Progress*SizeW)/2,SizeH/3,SizeW-((Progress*SizeW)/2),SizeH/3}
      c.save();
      c.translate(Progress*(SizeW/2),0);
      c.drawLines(pts3,p);
      c.restore();
    end

   elseif isAnimType==3 then
    p.setStrokeCap(Paint.Cap.ROUND)
    p.setStrokeWidth(dip2px(2));
    c.save();
    c.translate(dip2px(20),((cHeight/2)-(SizeH/2)))
    pts1={0,SizeH/2,SizeW,SizeH/2}
    c.rotate(IsDO and Progress*-135 or Progress*135,SizeW/2,SizeH/2)
    c.drawLines(pts1,p)
    c.restore();

    pts2={SizeW/2,0,SizeW/2,SizeH}
    c.save();
    c.rotate(IsDO and Progress*-135 or Progress*135,SizeW/2,SizeH/2)
    c.drawLines(pts2,p);
    c.restore();
  end
end)
function Toasts(y)
  Toast.makeText(activity,y,Toast.LENGTH_SHORT).show()
  end


