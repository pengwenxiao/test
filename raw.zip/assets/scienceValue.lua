require"import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.widget.Toast"
import "android.graphics.Paint"
import "com.androlua.LuaDrawable"
import "android.widget.ListView"
import "android.widget.LinearLayout"
import "android.R$layout"
import "com.androlua.LuaAdapter"
import "android.view.WindowManager"
import "android.widget.TextView"
import "android.os.Build"
import "android.graphics.drawable.ColorDrawable"
import "android.widget.EditText"
import "android.R$id"
import "android.widget.ProgressBar"
import "android.view.View"
import "android.graphics.Typeface"
import "android.widget.CardView"
import "utils"
import "android.graphics.drawable.ColorDrawable"
activity.setTheme(android.R.style.Theme_Material_Light_DarkActionBar)
we=ActionBarColor
activity.ActionBar.setElevation(0)
activity.ActionBar.setBackgroundDrawable(ColorDrawable(we))
if Build.VERSION.SDK_INT >= 21 then
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(we);
end
activity.setTitle("科学常数")

layout={
  LinearLayout;
  focusable="true";
  focusableInTouchMode="true";
  orientation="vertical";
  {
    CardView;
    background="#FFFFFF";
    layout_width="-1";
    layout_margin="5dp";
    radius="10";
    CardElevation="0dp";
  {
    EditText;
    id="编辑框";
    layout_width="fill";
    background="0";
    Hint="搜索常量";
    hintTextColor= ActionBarColor;
    singleLine=true;
    textSize="14sp";
  };
};
  {
    ProgressBar;
    id="progress";
    layout_height="fill";
    layout_width="fill";
    padding="40%w";
  };
  {
    ListView;
    id="listview";
    layout_width="fill";
    layout_height="fill";
    layout_weight="1";
    DividerHeight=0;
  };
};



activity.setContentView(loadlayout(layout))

layouts={
  LinearLayout;
  layout_width="-1";
  orientation="horizontal";
  gravity="center|left";
  {
    CardView;
    radius="5";
    layout_marginRight="5dp";
    layout_marginLeft="5dp";
    CardElevation="0dp";
    layout_width="fill";
    layout_marginBottom="5dp";
    layout_marginTop="5dp";
    background="#ffffff";
    {
      LinearLayout;
      layout_width="-1";
      orientation="horizontal";
      gravity="center|left";
       {
      LinearLayout;
      orientation="horizontal";
      backgroundColor=ActionBarColor;
      gravity="center";
      {
        TextView;
        id="iv";
        textColor=0xFFFFFFFF;
        layout_width="50sp";
        layout_height="50sp";
        layout_margin="5dp";
        gravity="center";
        textSize="30sp";
      };
    };
      {
        LinearLayout;
        orientation="vertical";
        {
          TextView;
          text="常量";
          layout_marginLeft="20sp";
          textSize="15sp";
          Typeface=Typeface.defaultFromStyle(Typeface.BOLD);
          id="tv";
          textColor= ActionBarColor;
        };
        {
          TextView;
          layout_marginLeft="20sp";
          id="tv1";
          textSize="12sp";
          textColor="#ff777777";
          text="值";
        };
      };
    };

  };
};

  data={}
  adp=LuaAdapter(activity,data,layouts)
  a=1
  valueName={
    {"普朗克常数","6.63×10^－34","h"},
    {"真空中光速","299792458±1.2","C"},
    {"引力常数","6.67×10－11","G0"},
    {"阿伏加德罗常数","6.02×10^23","NA"},
    {"普适气体常数","8.31","R"},
    {"玻尔兹曼常数","1.38×10^－23","k"},
    {"理想气体摩尔体积","22.4×10^－3","Vm"},
    {"基本电荷(元电荷)","-1.602×10^－19","e"},
    {"原子质量单位","1.66×10^－27","u"},
    {"电子静止质量","9.11×10^－31","me"},
    {"电子荷质比","-1.76×10^11","e/me"},
    {"法拉第常数","96500","F"}, 
    {"中子静止质量","1.675×10^－27","mn"},
    {"真空电容率","8.85×10^－12","ε0"},
    {"真空磁导率","4π×10^-7","μ0"},
    {"电子磁矩","9.28×10^－24","μe"},
    {"质子磁矩","1.41×10^－23","μp"},
    {"玻尔(Bohr)磁子","9.27×10^－24","μB"},
    {"玻尔(Bohr)半径","5.29×10^－11","α0"},
    {"约化普朗克","1.067×10^-35","J·s"},
    {"里德伯常数","1.097373177(83)×10^7","R"},}
  while a~=#valueName do
    table.insert(data,{iv=valueName[a][3],tv=valueName[a][1],tv1=valueName[a][2]})
    a=a+1
  end
  listview.Adapter=adp
  progress.setVisibility(View.GONE)

function 搜索(c)
  c=tostring(c)
  data1={}
  for k,v in pairs(data) do
    if tostring(v.tv):find(c) then
      table.insert(data1,v)
      adp1=LuaAdapter(activity,data1,layouts)
      listview.Adapter=adp1
    end
  end
end

编辑框.addTextChangedListener{
  onTextChanged=function(c)
    if tostring(c)=="" then
      --显示全部
      listview.Adapter=adp
     else
      搜索(c) --进行搜索
    end
  end}







