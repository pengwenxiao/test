require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.view.animation.*"
import "android.view.animation.Animation$AnimationListener"

activity.setRequestedOrientation(6)
--屏幕设置
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
activity.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE)
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
activity.setTheme(android.R.style.Theme_Material_Light_NoActionBar)
activity.ActionBar.hide()
layout={
  FrameLayout,
  layout_width="fill",
  layout_height="fill",

  {
    LinearLayout,
    orientation="vertical",
    layout_width="fill",
    layout_height="fill",
    gravity="center",
    {
      LinearLayout,
      layout_width="fill",
      layout_height="fill",
      gravity="center",
      background="#000000",
    
      {
        Button,
        layout_weight="1",
        background="#00000000",
        textSize="100dp",
        textColor="#FFaaaaaa",
        id="btn1",
      },
      {
        Button,
        layout_weight="1",
        background="#00000000",
        textSize="100dp",
        textColor="#FFaaaaaa",
        id="btn2",
      },
      {
        Button,
        layout_weight="1",
        background="#00000000",
        textSize="100dp",
        textColor="#FFaaaaaa",
        text=":",
      },
      {
        Button,
        layout_weight="1",
        background="#00000000",
        textSize="100dp",
        textColor="#FFaaaaaa",
        id="btn3",
      },
      {
        Button,
        layout_weight="1",
        background="#00000000",
        textSize="100dp",
        textColor="#FFaaaaaa",
        id="btn4",
      },
      {
        Button,
        layout_weight="1",
        background="#00000000",
        textSize="100dp",
        textColor="#FFaaaaaa",
        text=":",
      },
      {
        Button,
        layout_weight="1",
        background="#00000000",
        textSize="100dp",
        textColor="#FFaaaaaa",
        id="btn5",
      },
      {
        Button,
        layout_weight="1",
        background="#00000000",
        textSize="100dp",
        textColor="#FFaaaaaa",
        id="btn6",
      },
    
    
    },

  },



  {
    LinearLayout,
    orientation="vertical",
    layout_width="fill",
    layout_height="fill",
    gravity="bottom|right",

    {
      TextView,
      layout_marginBottom="56dp",
      gravity="center|right",
      paddingRight="5%h",
      layout_width="fill",
      layout_height="56dp",
      textColor="#FFaaaaaa",
      text="书上有路勤为径，学海无涯苦作舟。",
    },

  },


}
activity.setContentView(loadlayout(layout))


--时,分动画
function setAnima(id,time)
  local s_z=TranslateAnimation(0, 0, -20, 0)
  s_z.setDuration(time)
  s_z.setFillAfter(true)
  s_z.setInterpolator(AnticipateOvershootInterpolator())
  id.startAnimation(s_z)
end


--秒动画
function setSAnima(id)
  
  local s_z=TranslateAnimation(0, 0, -20, 0)
  s_z.setDuration(500)
  s_z.setFillAfter(true)
  s_z.setInterpolator(AnticipateOvershootInterpolator())

  local z_t=TranslateAnimation(0,0,0,0)
  z_t.setDuration(100)
  z_t.setFillAfter(true)
  z_t.setInterpolator(LinearInterpolator())
  
  local z_x= AnimationSet(true)
  z_x_a=AlphaAnimation(1,0)
  z_x_a.setDuration(400)
  z_x_a.setFillAfter(true)
  z_x.addAnimation(z_x_a);
  z_x_y=TranslateAnimation(0,0,0,20)
  z_x_y.setDuration(400)
  z_x_y.setFillAfter(true)
  z_x_y.setInterpolator(LinearInterpolator())
  z_x.addAnimation(z_x_y);

  id.startAnimation(s_z)

  s_z.setAnimationListener(AnimationListener{
    onAnimationEnd=function()
      id.startAnimation(z_t)
    end,
  })
  z_t.setAnimationListener(AnimationListener{
    onAnimationEnd=function()
      id.startAnimation(z_x)
    end,
  })

end




function upData()
  
  H = os.date("%H")
  M = os.date("%M")
  S = os.date("%S")

  H_S = string.sub(H,1,1)
  H_G = string.sub(H,2,2)
  M_S = string.sub(M,1,1)
  M_G = string.sub(M,2,2)
  S_S = string.sub(S,1,1)
  S_G = string.sub(S,2,2)

  btn1.setText(H_S)
  btn2.setText(H_G)
  btn3.setText(M_S)
  btn4.setText(M_G)
  btn5.setText(S_S)
  btn6.setText(S_G)

  if O_H_S and O_H_G and O_M_S and O_M_G and O_S_S and O_S_G then

    if O_H_S~=H_S then

      setAnima(btn1,500)

    end

    if O_H_G~=H_G then

      setAnima(btn2,700)

    end

    if O_M_S~=M_S then

      setAnima(btn3,500)

    end

    if O_M_G~=M_G then

      setAnima(btn4,700)

    end

    if O_S_S~=S_S then

      setAnima(btn5,700)
      
    end

    if O_S_G~=S_G then

      setSAnima(btn6)

    end

  end

  O_H_S = string.sub(H,1,1)
  O_H_G = string.sub(H,2,2)
  O_M_S = string.sub(M,1,1)
  O_M_G = string.sub(M,2,2)
  O_S_S = string.sub(S,1,1)
  O_S_G = string.sub(S,2,2)

end


thread(function()
  require "import"
  while(true) do
    call("upData")
    Thread.sleep(1000)
  end
end)




