require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import"ku/ku"
import "android.graphics.drawable.ColorDrawable"
import "utils"
activity.setTitle('编辑计算界面')
xinjian={
  LinearLayout;
  orientation="vertical";
  id="tv";
  background="#F0F0F0";
  layout_width="fill";
  layout_height="75%h";
  {
    ScrollView;
    layout_width="fill";
    layout_height="75%h";
    {
  LinearLayout;
  orientation="vertical";
  
  layout_height="75%h";
  layout_width="fill";
  {
    CardView;
    layout_width="-1";
    
    radius="10";
    CardElevation="0dp";
    background="#FFFFFF";
    layout_margin="5dp";
    {
      EditText;
      textSize="14dp";
      id="标题";
      singleLine=true;
      layout_width="fill";
      textColor="#FF000000";
      hint="模块名称";
      background="#00000000";
      padding="10dp";
    };
  };
  {
    CardView;
    layout_width="-1";
    radius="10";
    CardElevation="0dp";
    background="#FFFFFF";
    layout_margin="5dp";
    {
      EditText;
      textSize="14dp";
      id="代码框";
      singleLine=false;
      layout_width="fill";
      textColor="#FF000000";
      hint="运算逻辑";
      background="#00000000";
      padding="10dp";
    };
  };
};
};
  {
    LinearLayout;
  --  layout_marginTop="30dp";
    gravity="end";
    
    layout_width="fill";
    layout_height="fill";
    {
      Button;
      text="保存";
      textColor= ActionBarColor;
      id="新建";
      background="0";
    };
  };
};

activity.setContentView(loadlayout(xinjian))
activity.setTheme(android.R.style.Theme_DeviceDefault_Light_DarkActionBar)

脚本路径=...
路径=activity.getLuaDir().."/applet/"
actionBar = activity.getActionBar()
actionBar.setBackgroundDrawable(ColorDrawable(ActionBarColor))
actionBar.setElevation(dip2px(25))
if Build.VERSION.SDK_INT >= 21 then
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(ActionBarColor);
end
if 脚本路径 then
  标题.Text=(脚本路径):match("%/(.[^/]+)$")
  代码框.Text=fr(脚本路径)
end

新建.onClick=function()
 print( fw(路径..标题.Text,代码框.Text))
  activity.result({})
end

