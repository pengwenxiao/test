require "import"
import "android.widget.*"
import "android.view.*"
import "android.widget.*"
import "android.view.*"
import "utils"
layout={
  LinearLayout;
  orientation="vertical";
  id="tv";
  layout_width="fill";
  background="#F0F0F0";
  {
    CardView;
    background="#FFFFFF";
    layout_width="-1";
    CardElevation="0dp";
    radius="10";
    layout_margin="5dp";
    {
      LinearLayout;
      orientation="vertical";
      layout_height="fill";
      layout_width="fill";
      {
        TextView;
        textSize="16sp";
        padding="10dp";
        text="请填写你的个人信息";
      };
      {
        TextView;
        padding="10dp";
        text="我们将通过你填写的内容对你所使用的APP进行个性化定制。请认(sui)真(bian)填写，放心，我们不会将这些信息传送到我们的服务器，这纯粹是为了提升你的使用体验。";
      };
    };
  };
  {
    CardView;
    background="#FFFFFF";
    layout_width="-1";
    CardElevation="0dp";
    radius="10";
    layout_margin="5dp";
    {
      EditText;
      id="username";
      background="#00000000";
      layout_width="fill";
      textSize="14dp";
      hint="输入你的名字";
      singleLine=true;
      padding="10dp";
      textColor="#FF000000";
    };
  };
  {
    CardView;
    background="#FFFFFF";
    layout_width="-1";
    CardElevation="0dp";
    radius="10";
    layout_margin="5dp";
    {
      EditText;
      id="qq";
      background="#00000000";
      layout_width="fill";
      textSize="14dp";
      hint="输入你的QQ";
      singleLine=true;
      padding="10dp";
      textColor="#FF000000";
    };
  };
  {
    CardView;
    background="#FFFFFF";
    layout_width="-1";
    CardElevation="0dp";
    radius="10";
    layout_margin="5dp";
    {
      EditText;
      id="signer";
      background="#00000000";
      layout_width="fill";
      textSize="14dp";
      hint="填写你的个性签名";
      singleLine=true;
      padding="10dp";
      textColor="#FF000000";
    };
  };
  {
    CardView;
    background="#FFFFFF";
    layout_width="-1";
    CardElevation="0dp";
    radius="10";
    layout_margin="5dp";
    {
      EditText;
      id="targe";
      background="#00000000";
      layout_width="fill";
      textSize="14dp";
      hint="定下一个小目标，比如中考，高考。";
      singleLine=true;
      padding="10dp";
      textColor="#FF000000";
    };
  };
  {
    CardView;
    layout_gravity="end";
    background="#FFFFFF";
    layout_width="-1";
    CardElevation="0dp";
    radius="10";
    layout_margin="5dp";
    {
      TextView;

      background="#00000000";
      text="设置目标完成时间";
      textSize="14dp";
      singleLine=true;
      padding="10dp";
      textColor="#FF000000";
    };
    {
      LinearLayout;
      layout_gravity="end";
      layout_height="fill";
      layout_width="wrap_content";
      {
        Button;
        background="0";
        id="mButton";
        text="点我";
      };
    };
  };
  {
    CardView;
    layout_gravity="end";
    background="#FFFFFF";
    layout_width="-1";
    CardElevation="0dp";
    radius="10";
    layout_margin="5dp";
    {
      TextView;
      layout_gravity="center";
      id="show";
      background="#00000000";
      textSize="14dp";
      singleLine=true;
      padding="10dp";
      textColor="#FF000000";
    };
  };
  {
    LinearLayout;
    layout_width="fill";
    layout_marginTop="30dp";
    gravity="end";
    layout_height="fill";
    {
      CardView;
      layout_gravity="right";
      layout_height="60dp";
      radius="30dp";
      layout_marginBottom="15dp";
      id="card";
      layout_width="60dp";
      CardElevation="0dp";
      layout_marginTop="15dp";
      layout_marginLeft="15dp";
      layout_marginRight="15dp";
      {
        TextView;
        layout_gravity="center";
        id="apply";
        textSize="13sp";
        gravity="center";
        Text="提交";
      };
    };
  };
};

activity.setContentView(loadlayout(layout))
activity.setTheme(android.R.style.Theme_DeviceDefault_Light_DarkActionBar)

if this.getSharedData("username")~=nil then
username. setText(this.getSharedData("username"))
end
if this.getSharedData("qq")~=nil then
qq. setText(this.getSharedData("qq"))
end
if this.getSharedData("signer")~=nil then
signer. setText(this.getSharedData("signer"))
end
if this.getSharedData("targe")~=nil then
targe. setText(this.getSharedData("targe"))
end


actionBar = this.getActionBar();
actionBar.setBackgroundDrawable(San_1)
actionBar.setElevation(dip2px(25))
actionBar. setTitle("个人信息")
actionBar.setDisplayHomeAsUpEnabled(true);
--给返回按钮设置一个看不见的系统资源
actionBar.setHomeAsUpIndicator(android.R.drawable.divider_horizontal_dark)
--现在返回按钮从视觉上看是消失了那么他就多了一个标题与边缘的距离
activity.getWindow().setStatusBarColor(ActionBarColor);
function onOptionsItemSelected(item)
  print("定下一个小目标，比如先赚他一个亿")
end
import "android.app.AlertDialog"
mButton.onClick=function()
  TimeLayout={
    LinearLayout;
    layout_width="fill";
    orientation="vertical";
    {
      DatePicker;
      id="datepick";
    };
  };


  AlertDialog.Builder(this)
  .setView(loadlayout(TimeLayout))
  .setPositiveButton("确定",{onClick=function(v)
      local formatDate=datepick.getYear().."-"..(datepick.getMonth()+1).."-"..datepick.getDayOfMonth().." 0:00:00"
      show. setText(datepick.getYear().."年"..(datepick.getMonth()+1).."月"..datepick.getDayOfMonth().."日")
      this.setSharedData("targetTime", formatDate)
  end})
  .setNegativeButton("取消",nil)
  .show()
end

apply. onClick= function()
  this.setSharedData("username",tostring(username. Text) )
  this.setSharedData("qq",tostring(qq. Text) )
  this.setSharedData("targe",tostring(targe. Text) )
  this.setSharedData("signer",tostring(signer. Text) )
  activity.newActivity("main")
  activity. finish()
end